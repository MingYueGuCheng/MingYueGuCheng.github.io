#!/usr/local/bin/python
# -*- coding:utf-8 -*-

import sys
from datetime import datetime
import time

op = int(sys.argv[1])
time1 = sys.argv[2]
time2 = sys.argv[3]

#date1 = time.strftime("%a %b %d %H:%M:%S %Z %Y", time.localtime(time.time()))


if op == 0:
    date1 = datetime.strptime(time1, "%a %b %d %H:%M:%S %Z %Y")
    date2 = datetime.strptime(time2, "%a %b %d %H:%M:%S %Z %Y")
    date = datetime.now()

    date1 = datetime(date1.year, date1.month, date1.day)
    date2 = datetime(date2.year, date2.month, date2.day)
    date = datetime(date.year, date.month, date.day)
    print(date2 - date).days
elif op == 1:
    date1 = datetime.strptime(time1, "%a %b %d %H:%M:%S %Z %Y")
    print(date1.strftime("%Y-%m-%d"))
else:
    date2 = datetime.strptime(time2, "%a %b %d %H:%M:%S %Z %Y")
    print(date2.strftime("%Y-%m-%d"))






