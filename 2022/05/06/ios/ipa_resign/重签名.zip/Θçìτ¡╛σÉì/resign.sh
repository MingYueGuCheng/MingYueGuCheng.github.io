#!/bin/sh
FILE_PATH="$1"
CERS_FILE_PATH=$FILE_PATH"/cer"
IPAS_FILE_PATH=$FILE_PATH"/ipa"
LOG_PATH=$FILE_PATH"/log.md"
PRODUCT_PATH=$FILE_PATH"/product"
SHELL_PATH=$(cd "$(dirname "$0")"; pwd)

#echo "FILE_PATH:"$FILE_PATH
#echo "CERS_FILE_PATH:"$CERS_FILE_PATH
#echo "IPAS_FILE_PATH:"$IPAS_FILE_PATH

function clearCer() {
    local cers=(`find $1 -maxdepth 1 -name "*.mobileprovision" -or -name "*.json"`)
    for cer in ${cers[*]}
    do
        rm -f $cer
    done
}

function cpCer() {
    local cer_path=$1
    local file_path=$2
    local cers=(`find $cer_path -maxdepth 1 -name "*.mobileprovision" -or -name "*.json"`)
    
    for cer in ${cers[*]}
    do
        cp -f $cer $file_path
    done
}

function checkCer() {
    local cer_path=$1
#    echo "cer_path: $cer_path"
    
    local configs=(`find $cer_path -name "config.json"`)
    if [[ ${#configs[*]} == 0 ]];then
        return 1
    fi
    
    local cers=(`find $cer_path -maxdepth 1 -name "*.mobileprovision"`)
    if [[ ${#cers[*]} == 0 ]];then
        return 1
    fi

    local names=()
    local groups=()
    local eTimes=()
    for ((i = 0; i < ${#cers[*]}; i++))
    do
        local name=`/usr/libexec/PlistBuddy -c "Print Entitlements:application-identifier" /dev/stdin <<< $(/usr/bin/security cms -D -i ${cers[i]})`
        local group=`/usr/libexec/PlistBuddy -c "Print Entitlements:com.apple.security.application-groups:0" /dev/stdin <<< $(/usr/bin/security cms -D -i ${cers[i]})`
        local eTime=`/usr/libexec/PlistBuddy -c "Print ExpirationDate" /dev/stdin <<< $(/usr/bin/security cms -D -i ${cers[i]})`
        eTime=`/usr/bin/python $SHELL_PATH"/datetime_py.py" 2 "$eTime" "$eTime"`
        names[i]=$name
        groups[i]=$group
        eTimes[i]=$eTime
        
        echo "name:    "$name
        echo "group:   "$group
        echo "过期时间:  "$eTime
    done
    
    if [ ${#names[*]} -gt 1 ];then
        local flagStr1=${groups[0]}
        local flag1=true
        for (( i = 0; i < ${#names[*]}; i++ ))
        do
            if [ "$flagStr1" != "${groups[i]}" ];then
                flag1=false
                break
            fi
        done
        
        local flagStr2=${eTimes[0]}
        local flag2=true
        for (( i = 0; i < ${#names[*]}; i++ ))
        do
            if [ "$flagStr2" != "${eTimes[i]}" ];then
                flag2=false
                break
            fi
        done

        if [[ $flag1 == false ]] || [[ $flag1 == true && "$flagStr1" == "" ]];then
            echo "**[[group 信息不一致]]**:" >> $LOG_PATH
            for (( i = 0; i < ${#names[*]}; i++ ))
            do
                echo "name:    "${names[i]} >> $LOG_PATH
                echo "group:   "${groups[i]} >> $LOG_PATH
                echo "过期时间:  "${eTimes[i]} >> $LOG_PATH
            done
        elif [[ $flag2 == false ]] || [[ $flag2 == true && "$flagStr2" == "" ]];then
            echo "**[[过期时间 信息不一致]]**:" >> $LOG_PATH
            for (( i = 0; i < ${#names[*]}; i++ ))
            do
                echo "name:    "${names[i]} >> $LOG_PATH
                echo "group:   "${groups[i]} >> $LOG_PATH
                echo "过期时间:  "${eTimes[i]} >> $LOG_PATH
            done
        fi
        return 0
    elif [ ${#names[*]} -eq 1 ];then
        echo "name:    "${names[0]} >> $LOG_PATH
        echo "group:   "${groups[0]} >> $LOG_PATH
        echo "过期时间:  "${eTimes[0]} >> $LOG_PATH
        return 0
    else
        echo "证书信息异常"
        echo "证书信息异常" >> $LOG_PATH
        return 1
    fi
}

function resignIpa() {
    local ipa_path=$1
    local ipa_file_path=${ipa_path%/*}
    local ipa_name=${ipa_path##*/}
    local file_name=${ipa_file_path##*/}
    local cer_path=$2
    local short_v=$3
    local build_v=$4
    echo "配置签名环境..."
    checkCer $cer_path
    if [ $? != 0 ];then
        echo "证书检查无法通过"
        echo "====重签结束===="
        echo "证书检查无法通过" >> $LOG_PATH
        echo "====重签结束====" >> $LOG_PATH
        return 1
    fi
    # cp 证书
    cpCer $cer_path $ipa_file_path
    
    # short version
    local version=(${short_v//./ })
    version[(${#version[*]}-1)]=$((10#${version[(${#version[*]}-1)]}+1))
    version=$(IFS=.;echo "${version[*]}")

    local tmpPath=$(pwd)
    cd $ipa_file_path
    
    local script=$(echo `cat ${ipa_file_path}/config.json | python -c '''
import json,sys;
obj = json.load(sys.stdin);
str = ""
for key,value in obj["bundle_id"].items():
    str = str + " -p " + key + "=" + value
if str.strip() != "":
    str = "fastlane sigh resign --use_app_entitlements -i " + obj["signing_id"] + str
    print str
'''`)

    script=$script" --short_version ${version}"
    echo "签名："$script
    echo "签名："$script >> $LOG_PATH
    echo "====开始重签[$version-$build_v]===="
    echo "====开始重签[$version-$build_v]====" >> $LOG_PATH
    $script
    if [ $? == 0 ];then
        echo "...重签成功"
        echo "...重签成功" >> $LOG_PATH
        clearCer $ipa_file_path
        echo "====重签结束===="
        
        mkdir "${PRODUCT_PATH}/${file_name}"
        cp -rf $ipa_path "${PRODUCT_PATH}/${file_name}/${ipa_name%.*}-v${version}-${build_v}.ipa"
        rm -f ./$ipa_name
        
        cd $tmpPath
        return 0
    else
        echo "...重签失败"
        echo "...重签失败" >> $LOG_PATH
        clearCer $ipa_file_path
        echo "====重签结束===="
        
        cd $tmpPath
        return 1
    fi
}

function iterateIpa() {
    for i
    do
        # ipa的基础信息
        local ipa_path=$i
        local ipa_file_path=${ipa_path%/*}
        local ipa_name=${ipa_path##*/}
        local file_name=${ipa_file_path##*/}
        echo "*****************[ $file_name ]*************"
        echo "#****************#[ $file_name ]#*************#" >> $LOG_PATH
        echo "ipa name：     "$ipa_name
        echo "ipa name：     "$ipa_name >> $LOG_PATH

        local tmp=$(pwd)
        cd $ipa_file_path
        
        cp -Rf $ipa_name $ipa_name".zip"
        cp -Rf $ipa_name $ipa_name".tmp"
        
        unzip -oq $ipa_name".zip" "Payload/*.app/Info.plist"
        if [ $? == 0 ];then
            local appName=$(find ./Payload -maxdepth 1 -name *.app)
            appName=${appName##*/}
#            echo "appName: "$appName
            local bundle_id=`/usr/libexec/PlistBuddy -c "Print CFBundleIdentifier" "./Payload/$appName/Info.plist"`
            local short_v=`/usr/libexec/PlistBuddy -c "Print CFBundleShortVersionString" "./Payload/$appName/Info.plist"`
            local build_v=`/usr/libexec/PlistBuddy -c "Print CFBundleVersion" "./Payload/$appName/Info.plist"`
            
            rm -rf ./Payload
            rm -rf "./${ipa_name}.zip"
            
            echo "bundle id：    "$bundle_id
            echo "short version："$short_v
            echo "build version："$build_v
            
            echo "bundle id：    "$bundle_id >> $LOG_PATH
            echo "short version："$short_v >> $LOG_PATH
            echo "build version："$build_v >> $LOG_PATH
            
            if [ -d "${CERS_FILE_PATH}/${bundle_id}" ];then
                resignIpa "$ipa_path" "${CERS_FILE_PATH}/${bundle_id}" "$short_v" "$build_v"
                rm -rf "./$ipa_name"
                cp -Rf "./${ipa_name}.tmp" $ipa_name
                rm -rf "./${ipa_name}.tmp"
            else
                rm -rf "./${ipa_name}.tmp"
                echo "${bundle_id} 证书目录不存在，无法签名"
                echo "${bundle_id} 证书目录不存在，无法签名" >> $LOG_PATH
            fi
        else
            rm -rf ./Payload
            rm -rf "./${ipa_name}.zip"
            rm -rf "./${ipa_name}.tmp"
            echo $ipa_name" 解压失败，无法签名"
            echo $ipa_name" 解压失败，无法签名" >> $LOG_PATH
        fi
        
        cd $tmp
    done
}

main() {
    rm -f $LOG_PATH
    rm -rf ${PRODUCT_PATH}
    mkdir ${PRODUCT_PATH}
    
    # 遍历 *.ipa
    IPAS=(`find $IPAS_FILE_PATH -name "*.ipa"`)

    if [ ${#IPAS[*]} -le 0 ];then
        echo "没有需要签名的ipa"
    else
        echo "需要签名的ipa数量：${#IPAS[*]}"
        iterateIpa ${IPAS[*]}
    fi
}

main
