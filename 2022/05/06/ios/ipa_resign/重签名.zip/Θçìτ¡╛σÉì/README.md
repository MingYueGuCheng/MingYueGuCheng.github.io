## 1. 安装fastlane：
```
$ brew install fastlane
```

## 2. 安装重签证书
```
 获取证书sha1值
```
## 3. 目录结构
```
|-重签名
|--cer
|---xxx.xxx.xxx (需要重签ipa的主bundle id)
|----config.json （重签ipa的bundle id与描述文件对应关系）
|----*.mobileprovision （用来重签的描述文件）
|--ipa
|---应用名称 （便于查找）
|----*.ipa （重签前的ipa）
|--product （重签后的ipa）
|--log.md（重签日志）
```
[重签名.zip](src/ipa_resign/重签名.zip)

## 4. config.json 配置bundle id与需要用来签名的描述文件名称
```
{
    "signing_id": "证书的sha1值",
    "bundle_id": {
        "重签包的bundle id" : "用来重签的描述文件名称",
        "扩展的bundle id" : "用来重签的描述文件名称"
    }
}
```
## 5. 签名后版本号
```
short version自动+1，build version不变
```
## 6. datetime_py.py、resign.sh保持在同一个目录下
## 7. 执行签名
```
$ sh /Users/xxx/resign.sh /Users/xxx/重签名
```
